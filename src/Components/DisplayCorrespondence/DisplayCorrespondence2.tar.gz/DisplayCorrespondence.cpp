/*!
 * \file
 * \brief
 */

#include <memory>
#include <string>
#include <time.h>

#include "DisplayCorrespondence.hpp"
#include "Common/Logger.hpp"

namespace Processors {
namespace DisplayCorrespondence {

DisplayCorrespondence::DisplayCorrespondence(const std::string & name) :
	Base::Component(name), mode("mode", 0) {
	LOG(LTRACE) << "Hello DisplayCorrespondence\n";

	registerProperty( mode);
}

DisplayCorrespondence::~DisplayCorrespondence() {
	LOG(LTRACE) << "Good bye DisplayCorrespondence\n";
}

bool DisplayCorrespondence::onInit() {

	matched = registerEvent("matched");
	h_onNewImage.setup(this, &DisplayCorrespondence::onNewImage);
	registerHandler("onNewImage", &h_onNewImage);

	registerStream("in_image_params", &in_image_params);
	registerStream("in_img", &in_img);
	registerStream("in_path", &in_path);
	registerStream("out_image", &out_image);

	registerStream("in_MatchedSourceForTile", &in_MatchedSourceForTile);
	registerStream("in_PositionOfPatchesInImages",
			&in_PositionOfPatchesInImages);
	registerStream("in_MatchedPatchInMatcher", &in_MatchedPatchInMatcher);
	registerStream("in_DistanceMap", &in_DistanceMap);
	registerStream("in_all_file_paths", &in_all_file_paths);

	registerStream("in_match_map", &in_match_map);
	registerStream("in_match_quality", &in_match_quality);

	LOG(LTRACE) << "DisplayCorrespondence::initialize\n";

	// Register data streams, events and event handlers HERE!

	return true;
}

bool DisplayCorrespondence::onFinish() {
	LOG(LTRACE) << "DisplayCorrespondence::finish\n";

	return true;
}

bool DisplayCorrespondence::onStep() {
	LOG(LTRACE) << "DisplayCorrespondence::step\n";
	return true;
}

bool DisplayCorrespondence::onStop() {
	return true;
}

bool DisplayCorrespondence::onStart() {
	srand(time(NULL));
	return true;
}

void DisplayCorrespondence::onNewImage() {

	Mat image = in_img.read();
	std::string path = in_path.read();
	std::vector<int> image_params = in_image_params.read();
	std::vector<std::vector<int> > MatchedSourceForTile =
			in_MatchedSourceForTile.read();
	std::vector<int> PositionOfPatchesInImages =
			in_PositionOfPatchesInImages.read();
	std::vector<std::vector<int> > MatchedPatchInMatcher =
			in_MatchedPatchInMatcher.read();
	std::vector<std::vector<double> > DistanceMap = in_DistanceMap.read();
	std::vector<std::string> all_file_paths = in_all_file_paths.read();
	int files_number = all_file_paths.size();
	std::vector<double> QueryMatchMap = in_match_map.read();
	double match_quality = in_match_quality.read();

	int patches_cols = image_params[0];
	int patches_rows = image_params[1];
	int patchsize = image_params[2];

	int bd_cols = image_params[3];
	int bd_rows = image_params[4];
	int bd_patch_size = image_params[5];

	int queue_size = image_params[6];
	int BestMatchingImage = image_params[7];

	int image_cols = image_params[8];
	int image_rows = image_params[9];

	std::vector<std::vector<int> > BDMatchMap;
	BDMatchMap.resize(bd_cols * bd_rows);
	//for (int q = 0; q < bd_cols * bd_rows; q++) {
	//	BDMatchMap[q] = -1;
	//}

	int query_col;
	int query_row;
	int fn;
	
	std::cout<<"qs:"<<queue_size<<std::endl;
	/*=======================================================================*/
	/*************************************************************************/
	/*		create corresspondence map for DB image							 */
	/*************************************************************************/
	
	if (mode==3 || mode==4){
		for (int k = 0; k < patches_rows * patches_cols; k++) {
			int flag = 0;
			int zzz;
			//check if there is match of current patch to the best image
			for (zzz = 0; zzz < queue_size; zzz++) {
				if (MatchedSourceForTile[k][zzz] == BestMatchingImage) {
					flag = 1;
					break;
				}
			}
			if (flag) {
				//where in the image is the patch (all patches are numbered linearly in 1D. Like in progressive scan in TV from left to right and to next line)
				fn = PositionOfPatchesInImages[MatchedPatchInMatcher[k][zzz]];
				BDMatchMap[fn].push_back(k);
			}
		}
	}
	/*=======================================================================*/
	/*************************************************************************/
	/*				simple correspondence drawing							 */
	/*************************************************************************/
	if (mode == 0) {
		float nx, ny, mx, my;
		Mat outimg;
		//int query_col;
		//int query_row;


		std::vector<cv::KeyPoint> im1kp;
		std::vector<cv::KeyPoint> im2kp;
		std::vector<cv::DMatch> immatches;

		int tempc = 0;

		int cant = 0, cant2 = 0;
		//read query image
		Mat matchedim = cv::imread(path, -1);
		double color;

		for (int k = 0; k < patches_rows * patches_cols; k++) {
			int flag = 0;
			int zzz;
			//check if there is match of current patch to the best image
			for (zzz = 0; zzz < queue_size; zzz++) {
				if (MatchedSourceForTile[k][zzz] == BestMatchingImage) {
					flag = 1;
					cant++;
					break;
				}
			}
			if (flag) {

				//where in the image is the patch (all patches are numbered linearly in 1D. Like in progressive scan in TV from left to right and to next line)
				fn = PositionOfPatchesInImages[MatchedPatchInMatcher[k][zzz]];
				//BDMatchMap[fn] = k;

				//error?
				if (fn < 0) {
					return;
				}

				//location of the center tile in the image#include <time.h>
				nx = bd_patch_size * (fn % bd_cols) + bd_patch_size * 0.5;
				ny = bd_patch_size * (fn / bd_cols) + bd_patch_size * 0.5;

				//which tile is matched
				query_col = k % patches_cols;
				query_row = k / patches_cols;

				//location of the center
				mx = patchsize * (query_col) + 0.5 * patchsize;
				my = patchsize * (query_row) + 0.5 * patchsize;

				//Is it not a bad match?
				if (DistanceMap[k][0] < 0 || DistanceMap[k][0] > 0.3) {
					cant2++;
					continue;
				}

				//choose colour
				//color = (1 - 10 * DistanceMap[k][0] * DistanceMap[k][0]) * 255.0;
				int cb = 0, cg = 0, cr = 255;
				int qLineW = 2, bdLineW = 2;
				//cb=rand() % 255;
				//cg=rand() % 255;
				//cr=rand() % 255;

				//draw patches in query img
				rectangle(image, Point(mx - 0.5 * patchsize, my - 0.5
						* patchsize), Point(mx + 0.5 * patchsize, my + 0.5
						* patchsize), Scalar(cb, cg, cr), qLineW);

				//draw patches in BD img
				rectangle(matchedim, Point(nx - 0.5 * bd_patch_size, ny - 0.5
						* bd_patch_size), Point(nx + 0.5 * bd_patch_size, ny
						+ 0.5 * bd_patch_size), Scalar(cb, cg, cr), bdLineW);

				//each tile center as a KP
				im1kp.push_back(KeyPoint(Point2f(nx, ny), 5.0));
				im2kp.push_back(KeyPoint(Point2f(mx, my), 5.0));

				std::ostringstream q;
				q.precision(2);
				q << QueryMatchMap[k];

				//putText(image, q.str(), cvPoint(mx-0.25*patchsize,my-0.125*patchsize), FONT_HERSHEY_SIMPLEX, 0.5, cvScalar(0,0,0), 1.5, CV_AA);

				//and now set correspondence
				immatches.push_back(DMatch(tempc, tempc, 0.0));
				tempc++;
			}
		}
		drawMatches(image, im2kp, matchedim, im1kp, immatches, outimg,
				Scalar::all(-1));
		out_image.write(outimg);
	}

	/*=======================================================================*/
	/*************************************************************************/
	/*				corresponding tiles mareked with the same color			 */
	/*************************************************************************/
	if (mode == 3) {
		std::cout << "mode:" << mode << " s" << BDMatchMap.size() << std::endl;
		Mat matchedim = cv::imread(path, -1);
		float nx, ny, mx, my;
		Mat outimg;
		std::vector<cv::KeyPoint> im1kp;
		std::vector<cv::KeyPoint> im2kp;
		std::vector<cv::DMatch> immatches;

		
		int k;
		for (int m=0; m<BDMatchMap.size(); m++){
			int cb = 0, cg = 0, cr = 255;
			int qLineW = -1, bdLineW = -1;
			cb = rand() % 255;
			cg = rand() % 255;
			cr = rand() % 255;
			if (BDMatchMap[m].size()>0){
			for (int n=0; n<BDMatchMap[m].size(); n++){
				k=BDMatchMap[m][n];
				fn=n;
				
				query_col = k % patches_cols;
					query_row = k / patches_cols;

					//std::cout<<query_col<<" "<<query_row<<" "<<k<<std::endl;

					//location of the center
					mx = patchsize * (query_col) + 0.5 * patchsize;
					my = patchsize * (query_row) + 0.5 * patchsize;

					//Is it not a bad match?
					if (DistanceMap[k][0] < 0 || DistanceMap[k][0] > 0.3) {
						continue;
					}

					//draw patches in query img
					rectangle(image, Point(mx - 0.5 * patchsize, my - 0.5
							* patchsize), Point(mx + 0.5 * patchsize, my + 0.5
							* patchsize), Scalar(cb, cg, cr), qLineW);
				}
			
			nx = bd_patch_size * (m % bd_cols) + bd_patch_size * 0.5;
			ny = bd_patch_size * (m / bd_cols) + bd_patch_size * 0.5;

			//draw patches in BD img
			rectangle(matchedim, Point(nx - 0.5 * bd_patch_size, ny - 0.5
					* bd_patch_size), Point(nx + 0.5 * bd_patch_size, ny + 0.5
					* bd_patch_size), Scalar(cb, cg, cr), bdLineW);
			}
		}
		drawMatches(image, im2kp, matchedim, im1kp, immatches, outimg,
				Scalar::all(-1));

		out_image.write(outimg);
	}
	
	/*=======================================================================*/
	/*************************************************************************/
	/*			experimental mode to reconstruct image from matched patches	 */
	/*						  possible only when patches have the same size  */
	/*************************************************************************/
	//
	if ((mode == 1 && patchsize == bd_patch_size) || mode == 2) {

		int nx, ny, mx, my;
		//int fn;
		//int query_col;
		//int query_row;

		int ax, bx, ay, by;
		int fx;
		int r, g, b;
		Mat outimage(image_rows, image_cols, CV_8UC3,
				Scalar(0.0, 0.0, 0.0, 1.0));

		int counter = 0;
		int zzz = 0, flag = 0;

		//scan through all the files
		for (int l = 0; l < files_number; l++) {

			Mat matchedim = cv::imread(all_file_paths[l], -1);
			unsigned char *input = (unsigned char*) (matchedim.data);

			for (int k = 0; k < patches_rows * patches_cols; k++) {
				//matches only to the best image
				if (mode == 1) {
					flag = 0;
					//find if an image has some corresponging match on the list
					for (zzz = 0; zzz < queue_size; zzz++) {
						if (MatchedSourceForTile[k][zzz] == BestMatchingImage) {
							flag = 1;
							break;
						}
					}
				}
				//matches to all img in the DB
				if (flag || mode == 2) {

					query_col = k % patches_cols;
					query_row = k / patches_cols;
					mx = patchsize * (query_col);
					my = patchsize * (query_row);

					fn
							= PositionOfPatchesInImages[MatchedPatchInMatcher[k][zzz]];

					nx = bd_patch_size * (fn % bd_cols);
					ny = bd_patch_size * (fn / bd_cols);

					//if the tile is matched to the current image l
					if (MatchedSourceForTile[k][zzz] == l) {

						//then copy image pixel-by-pixel
						for (int ax = 0; ax < patchsize; ax++) {
							for (int ay = 0; ay < patchsize; ay++) {
								//outimage[mx+ax][mx+ay]=matchedim[nx+ax][nx+ay];
								//if ((ax+nx)>512||(ay+ny))
								b = matchedim.data[matchedim.step[0]
										* (ay + ny) + matchedim.step[1] * (ax
										+ nx)];
								g = matchedim.data[matchedim.step[0]
										* (ay + ny) + matchedim.step[1] * (ax
										+ nx) + 1];
								r = matchedim.data[matchedim.step[0]
										* (ay + ny) + matchedim.step[1] * (ax
										+ nx) + 2];

								outimage.data[outimage.step[0] * (my + ay)
										+ outimage.step[1] * (mx + ax) + 0] = b;
								outimage.data[outimage.step[0] * (my + ay)
										+ outimage.step[1] * (mx + ax) + 1] = g;
								outimage.data[outimage.step[0] * (my + ay)
										+ outimage.step[1] * (mx + ax) + 2] = r;

							}
						}
					}
				}
			}
		}

		std::cout << "done" << std::endl;
		out_image.write(outimage);
	}
	/*************************************************************************/

	std::cout << "raise" << std::endl;
	matched->raise();
}

}//: namespace DisplayCorrespondence
}//: namespace Processors
